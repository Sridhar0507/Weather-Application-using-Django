from django.contrib import admin
from Weather_app.models import City
# Register your models here.
# class CityAdmin(admin.ModelAdmin):
#     cityadmin= ['name']

admin.site.register(City)
