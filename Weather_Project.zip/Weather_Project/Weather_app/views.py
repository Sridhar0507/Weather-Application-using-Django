import requests
from django.shortcuts import render,redirect
from Weather_app.forms import CityForm
from Weather_app.models import City
from django.contrib import messages


# Create your views here.
def check(request):
    url = 'http://api.openweathermap.org/data/2.5/weather?q={},&appid=3cbacbcb714ff4d64ba11b5b9f29913d&units=metric'
    if request.method == "POST":
        form = CityForm(request.POST)
        if form.is_valid():
            NewCity = form.cleaned_data['name']
            Count_City = City.objects.filter(name=NewCity).count()
            if Count_City == 0:
                res = requests.get(url.format(NewCity)).json()
                if res['cod'] == 200:
                    form.save()
                    messages.success(request,""+NewCity+" Added Successfully...!!!")
                else:
                    messages.error(request,"City Doesn't Exist...!!!") 
            else:
                messages.error(request,"City Already Exists...!!!")
    form = CityForm()
    cities = City.objects.all()
    data=[]
    for city in cities:
        res=requests.get(url.format(city)).json()
        print(res)
        city_weather={
            'city':city,
            'temperature':res ['main'] ['temp'],
            'description':res['weather'][0] ['description'],
            'country': res['sys'] ['country'],
            'icon': res['weather'] [0] ['icon'],
            'coord':res['coord'] ['lon']
        }
        data.append(city_weather)
    context = {'data':data,'form':form}
    return render(request,'Weather_app/weather_app.html',context)

def delete_city(request,CName):
    city_del = City.objects.filter(name=CName)
    if city_del.exists():
        city_del.delete()
        messages.success(request," "+ f"{CName} Removed Succesfully...!!!")
    else:
        messages.error(request,f"{CName} Not Found....!!!")
    return redirect('Home')